%% Vectorization using Sparse Matrices
%
%% Vectorization

%% Sparse matrix

%% Example: assembling of discrete Laplacian operator

%% Example: node star

%% Example: eliminating hanging nodes