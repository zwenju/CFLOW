%% Adaptive Finite Element Method

%% Motivation

%% Solve

%% Estimate

%% Mark

%% Refine

%% Examples 

