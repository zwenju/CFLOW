%% Multigrid Method
%
%% Subspace correction method

%% Example: MG for 1-d Poisson equation

%% MG on bisection grids: 2-D

%% MG on bisection grids: 3-D

%% FAS: MG for non-linear equation 