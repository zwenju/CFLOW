%% Tutorials and Examples
%
% iFEM is a MATLAB software package containing robust, efficient, and
% easy-following codes for the main building blocks of adaptive finite
% element methods on unstructured simplicial grids in both two and three
% dimensions. Besides the simplicity and readability, sparse
% matrixlization, an innovative programming style for MATLAB, is introduced
% to improve the efficiency. 
%
% Here is an incomplete list of examples to quickly show what ifem can do.
% For detailed explanation, in the main window, type >> ifem introduction.

%% Finite Element Methods
% * <../example/html/Poissonfemrate.html Poissonfemrate>
% * <../example/html/examplelistdoc.html List of Examples>

%% Adaptive Finite Element Methods
% * <../example/html/Poissonafemrate.html Poissonafemrate>
