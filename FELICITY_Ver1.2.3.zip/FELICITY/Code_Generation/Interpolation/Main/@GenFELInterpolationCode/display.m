function display(obj)

disp('------------------------------------------');
disp('GenFELInterpolationCode:');
disp(' ');

display@Generic_GenFELCode(obj);

disp(' ');
disp('------------------------------------------');
disp(' ');

end