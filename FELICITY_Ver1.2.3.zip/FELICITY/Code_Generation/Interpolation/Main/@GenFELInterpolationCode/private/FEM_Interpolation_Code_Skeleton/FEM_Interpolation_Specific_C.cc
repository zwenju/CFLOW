    // set the 'Name' of the FEM interpolation
    Name = (char*) SpecificFEM_str;      // this should be the same as the Class identifier
    
    // get the "matrix-valued"-ness of the interpolation
    num_row = ROW_NC;
    num_col = COL_NC;

