/*
============================================================================================
   This file contains an implementation of a derived C++ Class from the abstract base class
   in 'FEM_Interpolation.cc'.

   NOTE: portions of this code are automatically generated!

   Copyright (c) 01-31-2013,  Shawn W. Walker
============================================================================================
*/

