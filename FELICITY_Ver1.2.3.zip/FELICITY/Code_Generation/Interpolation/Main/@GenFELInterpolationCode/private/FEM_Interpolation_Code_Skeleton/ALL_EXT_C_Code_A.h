/*
============================================================================================
   Big include file for all extra user-defined C-code.
   
   NOTE: portions of this code are automatically generated!
   
   Copyright (c) 05-31-2010,  Shawn W. Walker
============================================================================================
*/

