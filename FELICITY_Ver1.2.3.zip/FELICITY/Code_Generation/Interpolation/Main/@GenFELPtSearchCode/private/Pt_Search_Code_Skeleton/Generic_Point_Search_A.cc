/*
============================================================================================
   Methods for a C++ Class that does generic point seearching in meshes.

   NOTE: portions of this code are automatically generated!

   Copyright (c) 06-16-2014,  Shawn W. Walker
============================================================================================
*/

#define GPS Generic_Point_Search

/***************************************************************************************/
/* constructor */
GPS::GPS (const mxArray *prhs[])
{
