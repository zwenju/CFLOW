/*
============================================================================================
   This file contains an implementation of a derived C++ Class from the abstract base class
   in 'Mesh_Point_Search.cc'.

   NOTE: portions of this code are automatically generated!

   Copyright (c) 10-02-2015,  Shawn W. Walker
============================================================================================
*/

