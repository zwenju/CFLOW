/*
============================================================================================
   Header file for a C++ Class that contains methods for generic point searching
   of meshes.

   NOTE: portions of this code are automatically generated!

   Copyright (c) 06-16-2014,  Shawn W. Walker
============================================================================================
*/

