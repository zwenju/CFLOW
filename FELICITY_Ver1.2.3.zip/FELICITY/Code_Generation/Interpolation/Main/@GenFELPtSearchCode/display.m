function display(obj)

disp('------------------------------------------');
disp('GenFELPtSearchCode:');
disp(' ');

display@Generic_GenFELCode(obj);

disp(' ');
disp('------------------------------------------');
disp(' ');

end