function display(obj)

disp('Interp_L1toL3 Object: Convert Level 1 objects to Level 3 objects');

disp(obj);

end