function SubINT = Get_SubINT_struct()
%Get_SubINT_struct
%
%   This just inits the struct fieldnames.

% Copyright (c) 01-28-2013,  Shawn W. Walker

SubINT.GeomFunc_CPP     = [];
SubINT.Ccode_Frag       = [];
SubINT.cpp_index        = [];
SubINT.Row_Shift        = [];
SubINT.Col_Shift        = [];
SubINT.Eval_Interp_snip = [];

end