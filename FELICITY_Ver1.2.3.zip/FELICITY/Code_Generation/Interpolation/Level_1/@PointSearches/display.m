function display(obj)

disp('Level 1 Code: PointSearches');

disp(obj);

end