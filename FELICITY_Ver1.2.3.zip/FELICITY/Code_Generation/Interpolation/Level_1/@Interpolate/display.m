function display(obj)

disp('Level 1 Code: Interpolate');

disp(obj);

end