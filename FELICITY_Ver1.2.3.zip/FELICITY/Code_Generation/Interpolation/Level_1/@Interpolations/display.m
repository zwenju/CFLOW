function display(obj)

disp('Level 1 Code: Interpolations');

disp(obj);

end