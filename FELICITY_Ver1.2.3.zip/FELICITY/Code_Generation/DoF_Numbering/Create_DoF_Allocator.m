function [status, Path_To_Mex] = Create_DoF_Allocator(Elem,MEX_FileName,MEX_Dir,GenCode_SubDir)
%Create_DoF_Allocator
%
%   Generic compile procedure for generating MEX files that allocate DoFs for
%   given finite element spaces via FELICITY's code generation.
%
%   [status, Path_To_Mex] = Create_DoF_Allocator(Elem,MEX_FileName,MEX_Dir,GenCode_SubDir);
%
%   Elem         = array of element structs (as in the ./FELICITY/Elem_Defn
%                  directory) that represent the finite element spaces we want
%                  to allocate DoFs for.
%   MEX_FileName = (string) name of MEX file.
%   MEX_Dir      = (string) full path to the location of the MEX file.
%   GenCode_SubDir = (string) name of sub-dir of MEX_Dir to store the
%                    generated c++ code that implements the DoF allocator.
%                    If omitted, then the default sub-dir is
%                    'AutoGen_DoFNumbering'.

%   status       = success == 0 or failure ~= 0.
%   Path_To_Mex  = (string) full path to the MEX file.

% Copyright (c) 03-31-2017,  Shawn W. Walker

% error check Elem!

% other error checking
if (nargin < 3)
    error('Not enough input arguments!');
end
if (nargin < 4)
    GenCode_SubDir = 'AutoGen_DoFNumbering'; % default name
end

% generate and compile the code
FI = FELInterface(MEX_Dir);
[status, Path_To_Mex] = FI.Compile_DoF_Numbering(Elem,MEX_FileName,MEX_Dir,GenCode_SubDir);

end