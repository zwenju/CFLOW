function status = Plot_Nodal_Arrangement(obj)
%Plot_Nodal_Arrangement
%
%   This plots the arrangement of the DoF nodes.

% Copyright (c) 12-10-2010,  Shawn W. Walker

status = -1;

% fill this in!!!!!

end