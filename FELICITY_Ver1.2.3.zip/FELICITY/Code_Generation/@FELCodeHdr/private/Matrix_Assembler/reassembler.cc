/***

A matrix RE-assembler for MATLAB
Copyright (c) 2013
Shawn W. Walker

 * The [[Reassembler]] class accumulates element contributions into an
 * existing compressed sparse column matrix data structure.  Elements
 * that do not fit into the existing index structure are silently ignored,
 * but an error message is output to the MATLAB display.

****/

// #include <vector>
// #include <algorithm>

class MatrixReassembler: public AbstractAssembler {
public:
    MatrixReassembler(mwIndex* jc1, mwIndex* ir1, double* pr1, int m, int n) : AbstractAssembler(m, n)
        {
        nnz = (int) jc1[n];
        result = mxCreateSparse((mwSize)m, (mwSize)n, (mwSize)nnz, mxREAL);
        jc_ptr = (mwIndex*) mxGetJc(result);
        ir_ptr = (mwIndex*) mxGetIr(result);
        pr_ptr =  (double*) mxGetPr(result);
        // copy old sparsity pattern over
        std::copy(jc1, (jc1+n+1), jc_ptr);
        std::copy(ir1, (ir1+nnz), ir_ptr);
        std::fill(pr_ptr, pr_ptr+nnz, 0); // initialize to all zero matrix
        //std::copy(pr1, (pr1+nnz), pr_ptr); // copy old matrix over (for testing purposes)
        }
    ~MatrixReassembler () {}

    int nnz;

    void add_entries(const int*, const int*, const double*, const int&, const int&);
    void add_entries(const int*, const int*, const double*, const int&, const int&, const int*);
    void add_entries(const int*, const int*, const double*, const int&, const int&, const int*, const mwIndex**, const bool&);
    void add_entries_transpose(const int*, const int*, const double*, const int&, const int&);
    void add_entries_transpose(const int*, const int*, const double*, const int&, const int&, const int*);
    void add_entries_transpose(const int*, const int*, const double*, const int&, const int&, const int*, const mwIndex**, const bool&);

    mxArray* export_matrix() { return result; }

private:

    // access to data
    mwIndex* jc_ptr;
    mwIndex* ir_ptr;
    double*  pr_ptr;

    mxArray* result;
};

void MatrixReassembler::add_entries(const int* iAe, const int* jAe, const double* Ae, const int& mAe, const int& nAe)
{
    // loop through columns of local matrix
    for (int jj = 0; jj < nAe; ++jj, Ae += mAe) {
        const int  col_index = jAe[jj];

        if (col_index >= 0 && col_index < n) {
            const mwIndex* const start = ir_ptr+jc_ptr[col_index];
            const mwIndex* const   end = ir_ptr+jc_ptr[col_index+1];
            // loop through rows of local matrix
            for (int ii = 0; ii < mAe; ++ii) {
                // linear search to find row
                const int row_index = iAe[ii];
                const mwIndex* const p = std::find(start, end, row_index);

                // found index!
                if (p!=end) {
                    const int k = (int) (p - ir_ptr); // shift back to get index
                    pr_ptr[k] += Ae[ii]; // add it in
                }
                else
                    mexPrintf("Failed element update at this matrix entry: (%d, %d).\n", row_index, col_index);
            }
        }
    }
}

/* local_row_indices is sorted so that we loop through iAe in ascending order */
void MatrixReassembler::add_entries(const int* iAe, const int* jAe, const double* Ae, const int& mAe, const int& nAe,
                                    const int* local_row_indices)
{
    // loop through columns of local matrix
    for (int jj = 0; jj < nAe; ++jj, Ae += mAe) {
        const int  col_index = jAe[jj];

        if (col_index >= 0 && col_index < n) {
            const mwIndex*    row_find = ir_ptr+jc_ptr[col_index]; // start at the beginning
            const mwIndex* const   end = ir_ptr+jc_ptr[col_index+1];
            // loop through rows of local matrix
            for (int ii = 0; ii < mAe; ++ii) {
                // linear search to find row
                const int row_index = iAe[local_row_indices[ii]];
                row_find = std::find(row_find, end, row_index);

                // found index!
                if (row_find!=end) {
                    const int k = (int) (row_find - ir_ptr); // shift back to get index
                    pr_ptr[k] += Ae[local_row_indices[ii]]; // add it in
                    ++row_find; // go to next one
                }
                else
                    mexPrintf("Failed element update at this matrix entry: (%d, %d).\n", row_index, col_index);
            }
        }
    }
}

/* this also gives an initial guess for searching for the row_index;
   Warning: make sure the initial guess is valid! */
void MatrixReassembler::add_entries(const int* iAe, const int* jAe, const double* Ae, const int& mAe, const int& nAe,
                                    const int* local_row_indices, const mwIndex** row_find, const bool& reset)
{
    // loop through columns of local matrix
    for (int jj = 0; jj < nAe; ++jj, Ae += mAe) {
        const int  col_index = jAe[jj];

        if (col_index >= 0 && col_index < n) {
            if (reset) // start at the beginning
                row_find[jj]           = ir_ptr+jc_ptr[col_index];

            const mwIndex* const   end = ir_ptr+jc_ptr[col_index+1];
            // loop through rows of local matrix
            for (int ii = 0; ii < mAe; ++ii) {
                // linear search to find row
                const int row_index = iAe[local_row_indices[ii]];
                row_find[jj] = std::find(row_find[jj], end, row_index);

                // found index!
                if (row_find[jj]!=end) {
                    const int k = (int) (row_find[jj] - ir_ptr); // shift back to get index
                    pr_ptr[k] += Ae[local_row_indices[ii]]; // add it in
                    ++row_find[jj]; // go to next one
                }
                else
                    mexPrintf("Failed element update at this matrix entry: (%d, %d).\n", row_index, col_index);
            }
        }
    }
}

// /* add the transpose of the local FE matrix XXXXXXXXXXXXXXXXXXXXX  OLD*/
// void MatrixReassembler::add_entries_transpose(int* iAe, int* jAe, double* Ae, int mAe, int nAe,
                                              // int shift_i, int shift_j)
// {
    // // loop through cols of local matrix
    // for (int jj = 0; jj < nAe; ++jj, ++Ae) {
        // const int  col_index = jAe[jj] + shift_j;
        // mwIndex* const start = ir_ptr+jc_ptr[col_index];
        // mwIndex* const   end = ir_ptr+jc_ptr[col_index+1];

        // if (col_index >= 0 && col_index < n) {
            // // loop through rows of local matrix
            // for (int ii = 0; ii < mAe; ++ii) {
                // // linear search to find row
                // const int row_index = iAe[ii] + shift_i;
                // mwIndex* p = std::find(start, end, row_index);

                // // found index!
                // if (p!=end) {
                    // const int k = (int) (p - ir_ptr); // shift back to get index
                    // pr_ptr[k] += Ae[ii*nAe]; // add it in (the transpose, that is)
                // }
                // else
                    // mexPrintf("Failed element update at this matrix entry: (%d, %d).\n", row_index, col_index);
            // }
        // }
    // }
// }

/* the following sub-routines are for ading the transpose of the local FE matrix */

void MatrixReassembler::add_entries_transpose(const int* iAe, const int* jAe, const double* Ae, const int& mAe, const int& nAe)
{
    // loop through columns of local matrix
    for (int jj = 0; jj < nAe; ++jj, ++Ae) {
        const int  col_index = jAe[jj];

        if (col_index >= 0 && col_index < n) {
            const mwIndex* const start = ir_ptr+jc_ptr[col_index];
            const mwIndex* const   end = ir_ptr+jc_ptr[col_index+1];
            // loop through rows of local matrix
            for (int ii = 0; ii < mAe; ++ii) {
                // linear search to find row
                const int row_index = iAe[ii];
                const mwIndex* const p = std::find(start, end, row_index);

                // found index!
                if (p!=end) {
                    const int k = (int) (p - ir_ptr); // shift back to get index
                    pr_ptr[k] += Ae[ii*nAe]; // add it in (the transpose, that is)
                }
                else
                    mexPrintf("Failed element update at this matrix entry: (%d, %d).\n", row_index, col_index);
            }
        }
    }
}

/* local_row_indices is sorted so that we loop through iAe in ascending order */
void MatrixReassembler::add_entries_transpose(const int* iAe, const int* jAe, const double* Ae, const int& mAe, const int& nAe,
                                              const int* local_row_indices)
{
    // loop through columns of local matrix
    for (int jj = 0; jj < nAe; ++jj, ++Ae) {
        const int  col_index = jAe[jj];

        if (col_index >= 0 && col_index < n) {
            const mwIndex*    row_find = ir_ptr+jc_ptr[col_index]; // start at the beginning
            const mwIndex* const   end = ir_ptr+jc_ptr[col_index+1];
            // loop through rows of local matrix
            for (int ii = 0; ii < mAe; ++ii) {
                // linear search to find row
                const int row_index = iAe[local_row_indices[ii]];
                row_find = std::find(row_find, end, row_index);

                // found index!
                if (row_find!=end) {
                    const int k = (int) (row_find - ir_ptr); // shift back to get index
                    pr_ptr[k] += Ae[local_row_indices[ii]*nAe]; // add it in (the transpose, that is)
                    ++row_find; // go to next one
                }
                else
                    mexPrintf("Failed element update at this matrix entry: (%d, %d).\n", row_index, col_index);
            }
        }
    }
}

/* this also gives an initial guess for searching for the row_index;
   Warning: make sure the initial guess is valid! */
void MatrixReassembler::add_entries_transpose(const int* iAe, const int* jAe, const double* Ae, const int& mAe, const int& nAe,
                                              const int* local_row_indices, const mwIndex** row_find, const bool& reset)
{
    // loop through columns of local matrix
    for (int jj = 0; jj < nAe; ++jj, ++Ae) {
        const int  col_index = jAe[jj];

        if (col_index >= 0 && col_index < n) {
            if (reset) // start at the beginning
                row_find[jj]           = ir_ptr+jc_ptr[col_index];

            const mwIndex* const   end = ir_ptr+jc_ptr[col_index+1];
            // loop through rows of local matrix
            for (int ii = 0; ii < mAe; ++ii) {
                // linear search to find row
                const int row_index = iAe[local_row_indices[ii]];
                row_find[jj] = std::find(row_find[jj], end, row_index);

                // found index!
                if (row_find[jj]!=end) {
                    const int k = (int) (row_find[jj] - ir_ptr); // shift back to get index
                    pr_ptr[k] += Ae[local_row_indices[ii]*nAe]; // add it in (the transpose, that is)
                    ++row_find[jj]; // go to next one
                }
                else
                    mexPrintf("Failed element update at this matrix entry: (%d, %d).\n", row_index, col_index);
            }
        }
    }
}
