function SUB = Get_Subdomain_Struct()
%Get_Subdomain_Struct
%
%   This returns the basic structure for the subdomain data.

% Copyright (c) 04-15-2011,  Shawn W. Walker

SUB.Name = [];
SUB.Dim  = [];
SUB.Data = [];

end