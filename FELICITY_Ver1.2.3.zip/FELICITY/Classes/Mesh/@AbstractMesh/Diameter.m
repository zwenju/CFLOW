function [Diam, PH] = Diameter(obj,Num_Bins)
%Diameter
%
%   This computes the diameter of each element of the mesh.  Note: in 2-D
%   and 3-D, the diameter is *defined* to be the length of the longest
%   edge.  In 1-D, it is simply the length of the interval.
%
%   [Diam, PH] = obj.Diameter(Num_Bins);
%
%   Num_Bins = number of bins to use in histogram (optional argument).
%
%   Diam: Mx1 column vector, where each row contains the diameter of a
%         single element in the mesh.
%
%   PH = plot handle for the histogram (valid if Num_Bins > 0).

% Copyright (c) 08-29-2016,  Shawn W. Walker

Diam = Compute_Simplex_Diameters(obj.Points,obj.ConnectivityList);

if nargin < 2
    Num_Bins = 0;
end

if Num_Bins > 0
    PH = obj.Plot_Simplex_Diameters(Diam,Num_Bins);
else
    PH = [];
end

end