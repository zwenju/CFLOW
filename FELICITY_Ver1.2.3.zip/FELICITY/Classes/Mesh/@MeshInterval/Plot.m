function Plot_Handle = Plot(obj)
%Plot
%
%   This plots the entire interval mesh.
%
%   Plot_Handle = obj.Plot;

% Copyright (c) 08-19-2009,  Shawn W. Walker

Plot_Handle = obj.Plot_Subdomain_1D([]);

end