function VT = vertexTangent(obj,VI)
%vertexTangent
%
%   This mimics the analogous MATLAB:triangulation method (vertexNormal).
%
%   [WRITE HELP.] compute approximate tangent vector at vertices of space curve mesh.

% Copyright (c) 11-16-2016,  Shawn W. Walker

error('Not implemented!');

end