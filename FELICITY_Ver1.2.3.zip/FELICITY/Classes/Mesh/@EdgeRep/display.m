function display(obj)

disp(['             Points: Vertex  Coordinates,             size = ', '[', num2str(size(obj.Points)), ']']);
disp(['   ConnectivityList: Element Connectivity,            size = ', '[', num2str(size(obj.ConnectivityList)), ']']);

end