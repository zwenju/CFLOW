function TI = pointLocation(obj,QP)
%pointLocation
%
%   This mimics the analogous MATLAB:triangulation method (pointLocation).
%
%   See also triangulation.pointLocation.

% Copyright (c) 11-16-2016,  Shawn W. Walker

error('Not implemented!');

end