function FP = featurePoints(obj,filter_angle)
%featurePoints
%
%   This mimics the analogous MATLAB:triangulation method (featureEdges).
%
%   [WRITE HELP.] return sharp points of a space curve mesh.

% Copyright (c) 11-16-2016,  Shawn W. Walker

error('Not implemented!');

end