function VI = nearestNeighbor(obj,QP)
%nearestNeighbor
%
%   This mimics the analogous MATLAB:triangulation method (nearestNeighbor).
%
%   See also triangulation.nearestNeighbor.

% Copyright (c) 11-16-2016,  Shawn W. Walker

error('Not implemented!');

end