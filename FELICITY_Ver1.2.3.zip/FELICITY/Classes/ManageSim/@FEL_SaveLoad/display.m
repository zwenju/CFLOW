function display(obj)

disp(obj);

end