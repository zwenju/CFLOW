function display(obj)

disp('FEL_AbstractSim object:');
disp(obj);

end