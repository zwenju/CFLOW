function MI = Mesh_Info_Struct()
%Mesh_Info_Struct
%
%   Define the structure of the Mesh_Info for linking the DoFmap to a mesh.

% Copyright (c) 01-01-2011,  Shawn W. Walker

MI.Name     = [];
MI.SubName  = [];
MI.SubIndex = [];

end