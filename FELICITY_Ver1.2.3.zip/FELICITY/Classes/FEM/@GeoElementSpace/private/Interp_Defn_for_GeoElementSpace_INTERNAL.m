function INTERP = Interp_Defn_for_GeoElementSpace_INTERNAL(obj)
%Interp_Defn_for_GeoElementSpace_INTERNAL
%
%   Generic definition file for interpolating a function in the finite
%   element space.

% Copyright (c) 04-09-2017,  Shawn W. Walker

% define domain
Hold_All = Domain(obj.RefElem.Simplex_Type,obj.Num_Comp);

% define finite element spaces
Elem_Struct = eval([obj.RefElem.Element_Name, '();']);
GS = Element(Hold_All,Elem_Struct,obj.Num_Comp);

% define functions on FE spaces
f = Coef(GS);

% define expressions to interpolate
I_h_f = Interpolate(Hold_All, f.val);

% define geometry representation - Domain, (default piecewise linear)
G1 = GeoElement(Hold_All);

% define a set of interpolations to perform
INTERP = Interpolations(G1);

% collect all of the interpolations together
INTERP = INTERP.Append_Interpolation(I_h_f);

end