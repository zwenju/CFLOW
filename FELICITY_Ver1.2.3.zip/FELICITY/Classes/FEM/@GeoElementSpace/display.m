function display(obj)

% get number of geometric element spaces
Num_GE_Spaces = length(obj);

for oi=1:Num_GE_Spaces

disp('------------------------------------------');
disp(['GeoElementSpace(',num2str(oi),')']);
disp(' ');

disp(['            Name: Identifier                                =  ''',obj(oi).Name,'''']);
disp(['         RefElem: Reference Finite Element object:              ','']);
obj(oi).RefElem.display;
disp(['       Mesh_Info: Struct With Mesh Info For GE Space:           ','']);
disp(obj(oi).Mesh_Info);
if isempty(obj(oi).Mesh_Info.SubName)
    DOMAIN_NAME = obj(oi).Mesh_Info.Name;
else
    DOMAIN_NAME = obj(oi).Mesh_Info.SubName;
end
disp(['        ... so the finite element space is defined on ''', DOMAIN_NAME, '''.']);
disp(' ');
disp(['          DoFmap: Local-to-Global Element Map,          SIZE =  ',num2str(size(obj(oi).DoFmap)),'']);

disp(['           Fixed: Subdomains Where DoFs Are Fixed','']);
for ci = 1:obj.Num_Comp
    Num_Fixed_Domain = length(obj(oi).Fixed(ci).Domain);
    if (Num_Fixed_Domain > 0)
        disp(['                     Component ', num2str(ci), ':  Number of Fixed Domains =  ',num2str(Num_Fixed_Domain),'']);
        disp( '                     DoFs are fixed on:');
        for di=1:Num_Fixed_Domain
            DOM_str = obj(oi).Fixed(ci).Domain{di};
            disp(['                    ', '''', DOM_str, '''']);
        end
    end
    disp(' ');
end

disp(['          mex_Dir: Directory to store mex file for interpolation:    ', obj(oi).mex_Dir]);
disp(['mex_Interpolation: function handle to mex file for interpolation:    ', func2str(obj(oi).mex_Interpolation)]);

disp('------------------------------------------');
disp(' ');

end

end