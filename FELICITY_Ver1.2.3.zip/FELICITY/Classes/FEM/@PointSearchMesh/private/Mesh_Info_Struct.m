function MI = Mesh_Info_Struct()
%Mesh_Info_Struct
%
%   Define the structure of the Mesh_Info for linking the Point Searching
%   to a mesh.

% Copyright (c) 08-31-2016,  Shawn W. Walker

MI.Name      = [];
MI.Num_Cell  = [];
MI.Sub.Name  = [];

end